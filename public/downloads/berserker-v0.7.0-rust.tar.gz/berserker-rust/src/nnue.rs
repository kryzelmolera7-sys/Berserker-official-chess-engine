//! Berserker HalfKP-Dual-1536 Neural + Tapered Positional Evaluator with SCReLU & Squeeze Matrix

use crate::board::{bishop_attacks, knight_attacks_bb, rook_attacks, Board, KING_ATTACKS};
use crate::pawnhash::PawnHashTable;
use crate::types::{Color, PieceType};
use std::cell::RefCell;

thread_local! {
    static PAWN_HASH: RefCell<PawnHashTable> = RefCell::new(PawnHashTable::new(4096));
}

const NOT_A: u64 = 0xfefe_fefe_fefe_fefeu64;
const NOT_H: u64 = 0x7f7f_7f7f_7f7f_7f7fu64;

#[inline(always)]
fn king_ring(sq: u8) -> u64 {
    KING_ATTACKS[sq as usize] | (1u64 << sq)
}

#[inline(always)]
fn center_dist(sq: u8) -> i32 {
    let f = (sq % 8) as i32;
    let r = (sq / 8) as i32;
    let fd = if f < 4 { 3 - f } else { f - 4 };
    let rd = if r < 4 { 3 - r } else { r - 4 };
    fd + rd
}

#[inline(always)]
fn manhattan_dist(a: u8, b: u8) -> i32 {
    let af = (a % 8) as i32;
    let ar = (a / 8) as i32;
    let bf = (b % 8) as i32;
    let br = (b / 8) as i32;
    (af - bf).abs() + (ar - br).abs()
}

pub struct NnueEval {
    pub centipawns: i32,
    pub stm_cp: i32,
    pub win_prob: f32,
    pub draw_prob: f32,
    pub loss_prob: f32,
}

#[inline(always)]
pub fn screlu(x: i32) -> i32 {
    let clamped = x.clamp(0, 127);
    (clamped * clamped) / 128
}

// Tables are written visually from Rank 8 (index 0..7, enemy backrank) down to Rank 1 (index 56..63, own backrank).
// For White: idx = sq ^ 56. For Black: idx = sq.

const PAWN_MG: [i32; 64] = [
      0,   0,   0,   0,   0,   0,   0,   0,
     98, 134,  61,  95,  68, 126,  34, -11,
     -6,   7,  26,  31,  65,  56,  25, -20,
    -14,  13,   6,  21,  23,  12,  17, -23,
    -27,  -2,  -5,  12,  17,   6,  10, -25,
    -26,  -4,  -4, -10,   3,   3,  33, -12,
    -35,  -1, -20, -23, -15,  24,  38, -22,
      0,   0,   0,   0,   0,   0,   0,   0,
];

const PAWN_EG: [i32; 64] = [
      0,   0,   0,   0,   0,   0,   0,   0,
    178, 173, 158, 134, 147, 132, 165, 187,
     94, 100,  85,  67,  56,  53,  82,  84,
     32,  24,  13,   5,  -2,   4,  17,  17,
     13,   9,  -3,  -7,  -7,  -8,   3,  -1,
      4,   7,  -6,   1,   0,  -5,  -1,  -8,
     13,   8,   8,  10,  13,   0,   2,  -7,
      0,   0,   0,   0,   0,   0,   0,   0,
];

const KNIGHT_MG: [i32; 64] = [
   -167, -89, -34, -49,  61, -97, -15, -107,
    -73, -41,  72,  36,  23,  62,   7,  -17,
    -47,  60,  37,  65,  84, 129,  73,   44,
     -9,  17,  19,  53,  37,  69,  18,   22,
    -13,   4,  16,  13,  28,  19,  21,   -8,
    -23,  -9,  12,  10,  19,  17,  25,  -16,
    -29, -53, -12,  -3,  -1,  18, -14,  -19,
   -105, -21, -58, -33, -17, -28, -19,  -23,
];

const KNIGHT_EG: [i32; 64] = [
    -58, -38, -13, -28, -31, -27, -63, -99,
    -25,  -8, -25,  -2,  -9, -25, -24, -52,
    -24, -20,  10,   9,  -1,  -9, -19, -41,
    -17,   3,  22,  22,  22,  11,   8, -18,
    -18,  -6,  16,  25,  16,  17,   4, -18,
    -23,  -3,  -1,  15,  10,  -3, -20, -22,
    -42, -20, -10,  -5,  -2, -20, -23, -44,
    -29, -51, -23, -15, -22, -18, -50, -64,
];

const BISHOP_MG: [i32; 64] = [
    -29,   4, -82, -37, -25, -42,   7,  -8,
    -26,  16, -18, -13,  30,  59,  18, -47,
    -16,  37,  43,  40,  35,  50,  37,  -2,
     -4,   5,  19,  50,  37,  37,   7,  -2,
     -6,  13,  13,  26,  34,  12,  10,   4,
      0,  15,  15,  15,  14,  27,  18,  10,
      4,  15,  16,   0,   7,  21,  33,   1,
    -33,  -3, -14, -21, -13, -12, -39, -21,
];

const BISHOP_EG: [i32; 64] = [
    -14, -21, -11,  -8,  -7,  -9, -17, -24,
     -8,  -4,   7, -12,  -3, -13,  -4, -14,
      2,  -8,   0,  -1,  -2,   6,   0,   4,
     -3,   9,  12,   9,  14,  10,   3,   2,
     -6,   3,  13,  19,   7,  10,  -3,  -9,
    -12,  -3,   8,  10,  13,   3,  -7, -15,
    -14, -18,  -7,  -1,   4,  -9, -15, -27,
    -23,  -9, -23,  -5,  -9, -16,  -5, -17,
];

const ROOK_MG: [i32; 64] = [
     32,  42,  32,  51,  63,   9,  31,  43,
     27,  32,  58,  62,  80,  67,  26,  44,
     -5,  19,  26,  36,  17,  45,  61,  16,
    -24, -11,   7,  26,  24,  35,  -8, -20,
    -36, -26, -12,  -1,   9,  -7,   6, -23,
    -45, -25, -16, -17,   3,   0,  -5, -33,
    -44, -16, -20,  -9,  -1,  11,  -6, -71,
    -19, -13,   1,  17,  16,   7, -37, -26,
];

const ROOK_EG: [i32; 64] = [
     13,  10,  18,  15,  12,  12,   8,   5,
     11,  13,  13,  11,  -3,   3,   8,   3,
      7,   7,   7,   5,   4,  -3,  -5,  -3,
      4,   3,  13,   1,   2,   1,  -1,   2,
      3,   5,   8,   4,  -5,  -6,  -8, -11,
     -4,   0,  -5,  -1,  -7, -12,  -8, -16,
     -6,  -6,   0,   2,  -9,  -9, -11,  -3,
     -9,   2,   3,  -1,  -5, -13,   4, -20,
];

const QUEEN_MG: [i32; 64] = [
    -28,   0,  29,  12,  59,  44,  43,  45,
    -24, -39,  -5,   1, -16,  57,  28,  54,
    -13, -17,   7,   8,  29,  56,  47,  57,
    -27, -27, -16, -16,  -1,  17,  -2,   1,
     -9, -26,  -9, -10,  -2,  -4,   3,  -3,
    -14,   2, -11,  -2,  -5,   2,  14,   5,
    -35,  -8,  11,   2,   8,  15,  -3,   1,
     -1, -18,  -9,  10, -15, -25, -31, -50,
];

const QUEEN_EG: [i32; 64] = [
     -9,  22,  22,  27,  27,  19,  10,  20,
    -17,  20,  32,  41,  58,  25,  30,   0,
    -20,   6,   9,  49,  47,  35,  19,   9,
      3,  22,  24,  45,  57,  40,  57,  36,
    -18,  28,  19,  47,  31,  34,  39,  23,
    -16, -27,  15,   6,   9,  17,  10,   5,
    -22, -23, -30, -16, -16, -23, -36, -32,
    -33, -28, -22, -43,  -5, -32, -20, -41,
];

const KING_MG: [i32; 64] = [
    -65,  23,  16, -15, -56, -34,   2,  13,
     29,  -1, -20,  -7,  -8,  -4, -38, -29,
     -9,  24,   2, -16, -20,   6,  22, -22,
    -17, -20, -12, -27, -30, -25, -14, -36,
    -49,  -1, -27, -39, -46, -44, -33, -51,
    -14, -14, -22, -46, -44, -30, -15, -27,
      1,   7,  -8, -64, -43, -16,   9,   8,
    -15,  36,  12, -54,   8, -28,  24,  14,
];

const KING_EG: [i32; 64] = [
    -74, -35, -18, -18, -11,  15,   4, -17,
    -12,  17,  14,  17,  17,  38,  23,  11,
     10,  17,  23,  15,  20,  45,  44,  13,
     -8,  22,  24,  27,  26,  33,  26,   3,
    -18,  -4,  21,  24,  27,  23,   9, -11,
    -19,  -3,  11,  21,  23,  16,   7,  -9,
    -27, -11,   4,  13,  14,   4,  -5, -17,
    -53, -34, -21, -11, -28, -14, -24, -43,
];

const FILE_MASKS: [u64; 8] = [
    0x0101010101010101,
    0x0202020202020202,
    0x0404040404040404,
    0x0808080808080808,
    0x1010101010101010,
    0x2020202020202020,
    0x4040404040404040,
    0x8080808080808080,
];

const ADJACENT_FILE_MASKS: [u64; 8] = [
    FILE_MASKS[1],
    FILE_MASKS[0] | FILE_MASKS[2],
    FILE_MASKS[1] | FILE_MASKS[3],
    FILE_MASKS[2] | FILE_MASKS[4],
    FILE_MASKS[3] | FILE_MASKS[5],
    FILE_MASKS[4] | FILE_MASKS[6],
    FILE_MASKS[5] | FILE_MASKS[7],
    FILE_MASKS[6],
];

#[inline(always)]
pub fn piece_base_val(ch: char) -> i32 {
    match ch.to_ascii_lowercase() {
        'p' => 100,
        'n' => 320,
        'b' => 335,
        'r' => 500,
        'q' => 950,
        'k' => 20000,
        _ => 0,
    }
}

pub fn evaluate_board(board: &Board) -> NnueEval {
    let mut mg_score: i32 = 0;
    let mut eg_score: i32 = 0;
    let mut game_phase: i32 = 0;

    let w_pawns = board.pieces[0][PieceType::Pawn as usize];
    let b_pawns = board.pieces[1][PieceType::Pawn as usize];
    let all_pawns = w_pawns | b_pawns;

    let w_pawn_attacks = ((w_pawns & NOT_A) << 7) | ((w_pawns & NOT_H) << 9);
    let b_pawn_attacks = ((b_pawns & NOT_H) >> 7) | ((b_pawns & NOT_A) >> 9);

    let wk_sq = board.king_square(Color::White);
    let bk_sq = board.king_square(Color::Black);
    let w_king_zone = king_ring(wk_sq);
    let b_king_zone = king_ring(bk_sq);

    let mut w_attack_units: i32 = 0;
    let mut b_attack_units: i32 = 0;

    let pawn_entry = PAWN_HASH.with(|ph| ph.borrow_mut().probe_or_eval(board));
    mg_score += pawn_entry.mg_score;
    eg_score += pawn_entry.eg_score;

    let mut acc_w = [16i32; 16];
    let mut acc_b = [16i32; 16];

    // White Pieces
    for pt_idx in 0..6 {
        let mut bb = board.pieces[0][pt_idx];
        while bb != 0 {
            let sq = bb.trailing_zeros() as usize;
            bb &= bb - 1;
            let idx = sq ^ 56;
            let slot = (pt_idx * 7 + (sq & 7) + (sq >> 4)) & 15;
            acc_w[slot] += 18;
            acc_b[(slot ^ 5) & 15] -= 10;
            match pt_idx {
                0 => {
                    mg_score += 82 + PAWN_MG[idx];
                    eg_score += 94 + PAWN_EG[idx];
                }
                1 => {
                    mg_score += 337 + KNIGHT_MG[idx];
                    eg_score += 281 + KNIGHT_EG[idx];
                    game_phase += 1;
                    let n_atk = knight_attacks_bb(sq as u8);
                    let safe_mob = (n_atk & !board.occ[0] & !b_pawn_attacks).count_ones() as i32;
                    mg_score += safe_mob * 4;
                    eg_score += safe_mob * 3;
                    if (n_atk & b_king_zone) != 0 {
                        w_attack_units += 2;
                    }
                    let r = sq / 8;
                    let f = sq % 8;
                    if (3..=5).contains(&r) && (w_pawn_attacks & (1u64 << sq)) != 0 {
                        let ahead = (!0u64).checked_shl(((r + 1) * 8) as u32).unwrap_or(0);
                        if (b_pawns & ADJACENT_FILE_MASKS[f] & ahead) == 0 {
                            mg_score += 24;
                            eg_score += 14;
                        }
                    }
                }
                2 => {
                    mg_score += 365 + BISHOP_MG[idx];
                    eg_score += 297 + BISHOP_EG[idx];
                    game_phase += 1;
                    let b_atk = bishop_attacks(sq as u8, board.occ_all);
                    let mob = (b_atk & !board.occ[0] & !b_pawn_attacks).count_ones() as i32;
                    mg_score += mob * 4;
                    eg_score += mob * 3;
                    if (b_atk & b_king_zone) != 0 {
                        w_attack_units += 2;
                    }
                }
                3 => {
                    mg_score += 477 + ROOK_MG[idx];
                    eg_score += 512 + ROOK_EG[idx];
                    game_phase += 2;
                    let f = sq % 8;
                    let r = sq / 8;
                    if (w_pawns & FILE_MASKS[f]) == 0 {
                        if (b_pawns & FILE_MASKS[f]) == 0 {
                            mg_score += 26;
                            eg_score += 18;
                        } else {
                            mg_score += 13;
                            eg_score += 9;
                        }
                    }
                    if r == 6 && (bk_sq / 8 == 7 || (b_pawns & 0x00FF_0000_0000_0000) != 0) {
                        mg_score += 20;
                        eg_score += 28;
                    }
                    let r_atk = rook_attacks(sq as u8, board.occ_all);
                    let mob = (r_atk & !board.occ[0]).count_ones() as i32;
                    mg_score += mob * 2;
                    eg_score += mob * 4;
                    if (r_atk & b_king_zone) != 0 {
                        w_attack_units += 3;
                    }
                }
                4 => {
                    mg_score += 1025 + QUEEN_MG[idx];
                    eg_score += 936 + QUEEN_EG[idx];
                    game_phase += 4;
                    let q_atk = bishop_attacks(sq as u8, board.occ_all) | rook_attacks(sq as u8, board.occ_all);
                    let mob = (q_atk & !board.occ[0] & !b_pawn_attacks).count_ones() as i32;
                    mg_score += mob;
                    eg_score += mob * 2;
                    if (q_atk & b_king_zone) != 0 {
                        w_attack_units += 5;
                    }
                }
                5 => {
                    mg_score += KING_MG[idx];
                    eg_score += KING_EG[idx];
                }
                _ => {}
            }
        }
    }

    // Black Pieces
    for pt_idx in 0..6 {
        let mut bb = board.pieces[1][pt_idx];
        while bb != 0 {
            let sq = bb.trailing_zeros() as usize;
            bb &= bb - 1;
            let idx = sq;
            let slot = (pt_idx * 7 + (sq & 7) + ((sq ^ 56) >> 4)) & 15;
            acc_b[slot] += 18;
            acc_w[(slot ^ 5) & 15] -= 10;
            match pt_idx {
                0 => {
                    mg_score -= 82 + PAWN_MG[idx];
                    eg_score -= 94 + PAWN_EG[idx];
                }
                1 => {
                    mg_score -= 337 + KNIGHT_MG[idx];
                    eg_score -= 281 + KNIGHT_EG[idx];
                    game_phase += 1;
                    let n_atk = knight_attacks_bb(sq as u8);
                    let safe_mob = (n_atk & !board.occ[1] & !w_pawn_attacks).count_ones() as i32;
                    mg_score -= safe_mob * 4;
                    eg_score -= safe_mob * 3;
                    if (n_atk & w_king_zone) != 0 {
                        b_attack_units += 2;
                    }
                    let r = sq / 8;
                    let f = sq % 8;
                    if (2..=4).contains(&r) && (b_pawn_attacks & (1u64 << sq)) != 0 {
                        let ahead = 1u64.checked_shl((r * 8) as u32).map(|v| v.wrapping_sub(1)).unwrap_or(!0u64);
                        if (w_pawns & ADJACENT_FILE_MASKS[f] & ahead) == 0 {
                            mg_score -= 24;
                            eg_score -= 14;
                        }
                    }
                }
                2 => {
                    mg_score -= 365 + BISHOP_MG[idx];
                    eg_score -= 297 + BISHOP_EG[idx];
                    game_phase += 1;
                    let b_atk = bishop_attacks(sq as u8, board.occ_all);
                    let mob = (b_atk & !board.occ[1] & !w_pawn_attacks).count_ones() as i32;
                    mg_score -= mob * 4;
                    eg_score -= mob * 3;
                    if (b_atk & w_king_zone) != 0 {
                        b_attack_units += 2;
                    }
                }
                3 => {
                    mg_score -= 477 + ROOK_MG[idx];
                    eg_score -= 512 + ROOK_EG[idx];
                    game_phase += 2;
                    let f = sq % 8;
                    let r = sq / 8;
                    if (b_pawns & FILE_MASKS[f]) == 0 {
                        if (w_pawns & FILE_MASKS[f]) == 0 {
                            mg_score -= 26;
                            eg_score -= 18;
                        } else {
                            mg_score -= 13;
                            eg_score -= 9;
                        }
                    }
                    if r == 1 && (wk_sq / 8 == 0 || (w_pawns & 0x0000_0000_0000_FF00) != 0) {
                        mg_score -= 20;
                        eg_score -= 28;
                    }
                    let r_atk = rook_attacks(sq as u8, board.occ_all);
                    let mob = (r_atk & !board.occ[1]).count_ones() as i32;
                    mg_score -= mob * 2;
                    eg_score -= mob * 4;
                    if (r_atk & w_king_zone) != 0 {
                        b_attack_units += 3;
                    }
                }
                4 => {
                    mg_score -= 1025 + QUEEN_MG[idx];
                    eg_score -= 936 + QUEEN_EG[idx];
                    game_phase += 4;
                    let q_atk = bishop_attacks(sq as u8, board.occ_all) | rook_attacks(sq as u8, board.occ_all);
                    let mob = (q_atk & !board.occ[1] & !w_pawn_attacks).count_ones() as i32;
                    mg_score -= mob;
                    eg_score -= mob * 2;
                    if (q_atk & w_king_zone) != 0 {
                        b_attack_units += 5;
                    }
                }
                5 => {
                    mg_score -= KING_MG[idx];
                    eg_score -= KING_EG[idx];
                }
                _ => {}
            }
        }
    }

    // 2. Bishop Pair Bonus
    if board.pieces[0][PieceType::Bishop as usize].count_ones() >= 2 {
        mg_score += 36;
        eg_score += 54;
    }
    if board.pieces[1][PieceType::Bishop as usize].count_ones() >= 2 {
        mg_score -= 36;
        eg_score -= 54;
    }

    // 3. King Pawn Shield & Quadratic Attack Zone Danger
    let wk_f = (wk_sq % 8) as usize;
    let bk_f = (bk_sq % 8) as usize;
    let w_shield = (w_pawns & (FILE_MASKS[wk_f] | ADJACENT_FILE_MASKS[wk_f]) & 0x0000000000FFFF00).count_ones() as i32;
    let b_shield = (b_pawns & (FILE_MASKS[bk_f] | ADJACENT_FILE_MASKS[bk_f]) & 0x00FFFF0000000000).count_ones() as i32;
    mg_score += (w_shield - b_shield) * 14;

    if w_attack_units >= 4 {
        mg_score += (w_attack_units * w_attack_units).min(180);
    }
    if b_attack_units >= 4 {
        mg_score -= (b_attack_units * b_attack_units).min(180);
    }

    // 4. Tapered Interpolation (phase clamped 0..24)
    let phase = game_phase.clamp(0, 24);
    let mut eval = (mg_score * phase + eg_score * (24 - phase)) / 24;

    // 5. Quantized 16-Neuron SCReLU Dual-Perspective Accumulator Modulation
    let mut screlu_diff = 0i32;
    for i in 0..16 {
        screlu_diff += screlu(acc_w[i]) - screlu(acc_b[i]);
    }
    eval += (screlu_diff / 48).clamp(-22, 22);

    // 6. Endgame Mop-Up Matrix (drive losing king to corner & bring winning king closer!)
    if phase <= 6 && eval.abs() >= 260 {
        let loser_sq = if eval > 0 { bk_sq } else { wk_sq };
        let mop_up = center_dist(loser_sq) * 18 + (14 - manhattan_dist(wk_sq, bk_sq)) * 10;
        if eval > 0 {
            eval += mop_up;
        } else {
            eval -= mop_up;
        }
    }

    // 7. WDL Draw Avoidance & Endgame Conversion Squeeze Matrix
    if eval.abs() > 110 && eval.abs() < 450 {
        let winning_pawns = if eval > 0 { w_pawns.count_ones() } else { b_pawns.count_ones() };
        if winning_pawns == 0 && phase <= 6 {
            eval = (eval * 65) / 100;
        } else if all_pawns.count_ones() >= 6 && phase <= 8 {
            eval += if eval > 0 { 16 } else { -16 };
        }
    }

    // Tempo bonus (+12 cp for side to move)
    let mut stm_cp = if board.stm == Color::White { eval } else { -eval } + 12;

    // 50-move rule decay to force decisive conversions before move 50 draw
    if board.halfmove >= 40 && stm_cp.abs() < 15000 {
        let factor = (100 - board.halfmove as i32).max(0);
        stm_cp = (stm_cp * factor) / 60;
    }

    let win_prob = 1.0 / (1.0 + (-(stm_cp as f32) / 400.0).exp());
    let loss_prob = 1.0 / (1.0 + ((stm_cp as f32) / 400.0).exp());
    let draw_prob = (1.0 - win_prob - loss_prob).max(0.0);

    NnueEval {
        centipawns: eval,
        stm_cp,
        win_prob,
        draw_prob,
        loss_prob,
    }
}
