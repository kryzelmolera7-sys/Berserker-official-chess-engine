//! Lockless Shared Atomic Transposition Table (for Lazy SMP)

use crate::types::Move;
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum TTFlag {
    Exact = 0,
    Lowerbound = 1,
    Upperbound = 2,
}

impl TTFlag {
    #[inline(always)]
    pub fn from_u8(v: u8) -> Self {
        match v & 3 {
            0 => TTFlag::Exact,
            1 => TTFlag::Lowerbound,
            _ => TTFlag::Upperbound,
        }
    }
}

#[derive(Clone, Copy)]
pub struct TTEntry {
    pub depth: u8,
    pub score: i32,
    pub flag: TTFlag,
    pub best_move: Move,
}

/// Lockless XOR-verified 128-bit atomic slot (two AtomicU64s).
/// Safe for concurrent reads & writes across Lazy SMP worker threads without mutexes.
pub struct AtomicTTSlot {
    key_xor_data: AtomicU64,
    data: AtomicU64,
}

impl AtomicTTSlot {
    #[inline(always)]
    const fn empty() -> Self {
        Self {
            key_xor_data: AtomicU64::new(0),
            data: AtomicU64::new(0),
        }
    }
}

pub struct AtomicTT {
    slots: Vec<AtomicTTSlot>,
    mask: usize,
}

impl AtomicTT {
    pub fn new(size_mb: usize) -> Self {
        let slot_bytes = std::mem::size_of::<AtomicTTSlot>().max(16);
        let raw_entries = ((size_mb.max(1) * 1024 * 1024) / slot_bytes).max(4096);
        let size = raw_entries.next_power_of_two();
        let mut slots = Vec::with_capacity(size);
        for _ in 0..size {
            slots.push(AtomicTTSlot::empty());
        }
        Self {
            slots,
            mask: size - 1,
        }
    }

    pub fn clear(&self) {
        for slot in &self.slots {
            slot.key_xor_data.store(0, Ordering::Relaxed);
            slot.data.store(0, Ordering::Relaxed);
        }
    }

    #[inline(always)]
    fn pack_data(score: i32, depth: u8, flag: TTFlag, best_move: Move) -> u64 {
        let s16 = (score.clamp(-32000, 32000) as i16) as u16 as u64;
        let d8 = depth as u64;
        let f2 = (flag as u64) & 3;
        let mv24 = best_move.pack() as u64;
        s16 | (d8 << 16) | (f2 << 24) | (mv24 << 26)
    }

    #[inline(always)]
    fn unpack_data(data: u64) -> TTEntry {
        let s16 = (data & 0xFFFF) as u16 as i16;
        let depth = ((data >> 16) & 0xFF) as u8;
        let flag = TTFlag::from_u8(((data >> 24) & 3) as u8);
        let mv24 = ((data >> 26) & 0xFF_FFFF) as u32;
        TTEntry {
            depth,
            score: s16 as i32,
            flag,
            best_move: Move::unpack(mv24),
        }
    }

    #[inline(always)]
    pub fn probe(&self, hash: u64) -> Option<TTEntry> {
        let idx = (hash as usize) & self.mask;
        let slot = &self.slots[idx];
        let d = slot.data.load(Ordering::Relaxed);
        if d == 0 {
            return None;
        }
        let k = slot.key_xor_data.load(Ordering::Relaxed);
        if (k ^ d) == hash {
            Some(Self::unpack_data(d))
        } else {
            None
        }
    }

    #[inline(always)]
    pub fn store(&self, hash: u64, depth: u8, score: i32, flag: TTFlag, best_move: Move) {
        let idx = (hash as usize) & self.mask;
        let slot = &self.slots[idx];

        let existing_d = slot.data.load(Ordering::Relaxed);
        if existing_d != 0 {
            let existing_k = slot.key_xor_data.load(Ordering::Relaxed);
            if (existing_k ^ existing_d) == hash {
                let existing_depth = ((existing_d >> 16) & 0xFF) as u8;
                if existing_depth > depth + 1 && flag != TTFlag::Exact {
                    return;
                }
            }
        }

        let d = Self::pack_data(score, depth, flag, best_move);
        slot.data.store(d, Ordering::Relaxed);
        slot.key_xor_data.store(hash ^ d, Ordering::Relaxed);
    }
}
